#pragma once
#include "weapons.h"

using namespace std;

class enemy;
class player {
public:
	string name;
	int life;
	weapon& wpn;
	unsigned damage;

	player(string n, int l, weapon& w, unsigned dam);
	void attack(enemy& e);
	void fistattack(enemy& e);
};
