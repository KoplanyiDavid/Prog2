#pragma once
#include "weapons.h"
#include "player.h"

using namespace std;

class enemy {
public:
	string name;
	int life;
	unsigned dmg;

	enemy(string n, int l, unsigned d);
	virtual void attack(player&) = 0;
};

class zombie :public enemy {
public:
	int zlife;

	zombie(string n, int l, unsigned d, int zl);
	void attack(player& p);
};

class human :public enemy {
public:
	weapon& hw;

	human(string n, int l, unsigned d, weapon& w);
	void attack(player& p);
};
