#define _CRT_SECURE_NO_WARNINGS
#include "weapons.h"

weapon::weapon(unsigned d, int du, unsigned h, string n) :damage(d), durability(du), handling(h), name(n) {}

meele::meele(unsigned d, int du, unsigned h, string n, string t):weapon(d, du, h, n), type(t) {}

gun::gun(unsigned d, int du, unsigned h, string n, unsigned bn) :weapon(d, du, h, n), bullet(bn) {}

void meele::usegun() {
	this->durability--;
}

void gun::usegun()
{
	this->bullet--;
	this->durability--;
}
