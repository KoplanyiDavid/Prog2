#pragma once
#include <string>

using namespace std;

class weapon {
public:
	unsigned damage;
	int durability;
	unsigned handling;
	string name;

	weapon(unsigned d, int du, unsigned h, string n);
	virtual void usegun() = 0;
};

class meele : public weapon {
public:
	string type;

	meele(unsigned d, int du, unsigned h, string n, string t);
	void usegun();
};

class gun :public weapon {
public:
	unsigned bullet;

	gun(unsigned d, int du, unsigned h, string n, unsigned bn);
	void usegun();
};
