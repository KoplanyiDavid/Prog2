#define _CRT_SECURE_NO_WARNINGS
#include "enemies.h"
#include "player.h"

enemy::enemy(string n, int l, unsigned d) :name(n), life(l), dmg(d) {}

zombie::zombie(string n, int l, unsigned d, int zl) :enemy(n, l+zl, d) {}

void zombie::attack(player& p)
{
	p.life -= this->dmg;
	this->life++;
}

human::human(string n, int l, unsigned d, weapon& w) :enemy(n, l, d), hw(w) {}

void human::attack(player & p)
{
	int damage = this->dmg + this->hw.damage;
	p.life -= damage;
}
