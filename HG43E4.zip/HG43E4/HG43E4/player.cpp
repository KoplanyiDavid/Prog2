#define _CRT_SECURE_NO_WARNINGS
#include "player.h"
#include "enemies.h"

player::player(string n, int l, weapon& w, unsigned dam) :name(n), life(l), wpn(w), damage(dam) {}

void player::attack(enemy& e)
{
	e.life -= (this->wpn.damage)+(this->wpn.handling);
}

void player::fistattack(enemy & e)
{
	e.life -= this->damage;
}
