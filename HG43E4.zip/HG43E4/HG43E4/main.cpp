#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "weapons.h"
#include "enemies.h"
#include "player.h"

using namespace std;

int main()
{
	cout << "Initializing weapons..." << endl;
	meele baseballb(5, 5, 3, "baseballbaton", "meele");
	gun pistol(65, 6, 2, "pistol", 16);
	cout << "Initializing enemy..." << endl;
	human h("human", 50, 1, baseballb);
	zombie z("zombie", 200, 25, 50);
	cout << "Your enemies are: " << h.name << z.name << endl;
	cout << "Initializing player..." << endl;
	player p1("player1", 100, baseballb, 10);
	player p2("player2", 100, pistol, 10);
	int a;
	cout << "Choose a player: 1. player1 (baseballbaton), 2. player2 (pistol)" << endl;
	cin >> a;
	if (a == 1)
	{
		cout << "Your weapon is: " << p1.wpn.name << endl << "Type of weapon: meele" << endl;
		cout << "What do you want to do? (attack, run)" << endl;
		string v;
		cin >> v;
		if (v == "run") {
			cout << "You survived the day." << endl;
		}
		if (v == "attack") {
			cout << "Who do you want to attack? (1: human, 2: zombie)" << endl;
			int a;
			cin >> a;
			if (a == 1) //p1 vs h
			{
				while (p1.life > 0 && h.life > 0) { //ciklikus �sszecsap�sok
					if (p1.wpn.durability > 0)
					{
						cout << "You attack: " << endl;
						p1.attack(h);
						p1.wpn.usegun();
						cout << "Human's life remaining: " << h.life << endl;
						cout << "Weapon durability remaining: " << p1.wpn.durability << endl;
						if (h.life <= 0)
						{
							cout << "Your enemy is dead." << endl;
							break;
						}
						cout << "Human attack: " << endl;
						h.attack(p1);
						cout << "Your life remaining: " << p1.life << endl;
						if (p1.life <= 0)
						{
							cout << "You are dead." << endl;
							break;
						}
					}
					if (p1.wpn.durability < 1)
					{
						cout << "You attack with fists: " << endl;
						p1.fistattack(h);
						cout << "Human's life remaining: " << h.life << endl;
						if (h.life <= 0)
						{
							cout << "Your enemy is dead." << endl;
							break;
						}
						cout << "Human attack: " << endl;
						h.attack(p1);
						cout << "Your life remaining: " << p1.life << endl;
						if (p1.life <= 0)
						{
							cout << "You are dead." << endl;
							break;
						}
					}
				}
			}
			if (a == 2) //p1 vs z
			{
				while (p1.life > 0 && z.life > 0) { //ciklikus �sszecsap�sok 
					if (p1.wpn.durability > 0)
					{
						cout << "You attack: " << endl;
						p1.attack(z);
						p1.wpn.usegun();
						cout << "Zombie's life remaining: " << z.life << endl;
						cout << "Weapon durability remaining: " << p1.wpn.durability << endl;
						if (z.life <= 0)
						{
							cout << "Your enemy is dead." << endl;
							break;
						}
						cout << "Zombie attack: " << endl;
						z.attack(p1);
						cout << "Your life remaining: " << p1.life << endl;
						if (p1.life <= 0)
						{
							cout << "You are dead." << endl;
							break;
						}
					}
					if (p1.wpn.durability < 1)
					{
						cout << "You attack with fists: " << endl;
						p1.fistattack(z);
						cout << "Zombie's life remaining: " << z.life << endl;
						if (z.life <= 0)
						{
							cout << "Your enemy is dead." << endl;
							break;
						}
						cout << "Zombie attack: " << endl;
						z.attack(p1);
						cout << "Your life remaining: " << p1.life << endl;
						if (p1.life <= 0)
						{
							cout << "You are dead." << endl;
							break;
						}
					}

				}
			}
			/*else {
				cout << "ERROR" << endl;
			}*/
		}
		/*else {
			cout << "ERROR" << endl;
		}*/
	}
	if (a == 2) //p2
	{
		cout << "Your weapon is: " << p2.wpn.name << endl << "Type of weapon: gun" << endl;
		cout << "What do you want to do? (attack, run)" << endl;
		string v;
		cin >> v;
		if (v == "run") {
			cout << "You survived the day" << endl;
		}
		if (v == "attack") {
			cout << "Who do you want to attack? (1: human, 2: zombie)" << endl;
			int a;
			cin >> a;
			if (a == 1) //p2 vs h
			{
				while (p2.life > 0 && h.life > 0 && pistol.bullet > 0) { //ciklikus �sszecsap�sok
					if (p2.wpn.durability > 0)
					{
						cout << "You attack: " << endl;
						p2.attack(h);
						p2.wpn.usegun();
						cout << "Human's life remaining: " << h.life << endl;
						cout << "Weapon durability remaining: " << p2.wpn.durability << endl;
						if (h.life <= 0)
						{
							cout << "Your enemy is dead." << endl;
							break;
						}
						cout << "Human attack: " << endl;
						h.attack(p2);
						cout << "Your life remaining: " << p2.life << endl;
						if (p2.life <= 0)
						{
							cout << "You are dead." << endl;
							break;
						}
					}
					if (p2.wpn.durability < 1)
					{
						cout << "You attack with fists: " << endl;
						p2.fistattack(h);
						cout << "Human's life remaining: " << h.life << endl;
						if (h.life <= 0)
						{
							cout << "Your enemy is dead." << endl;
							break;
						}
						cout << "Human attack: " << endl;
						h.attack(p2);
						cout << "Your life remaining: " << p2.life << endl;
						if (p2.life <= 0)
						{
							cout << "You are dead." << endl;
							break;
						}
					}

				}
			}
			if (a == 2) //p2 vs z
			{
				while (p2.life > 0 && z.life > 0 && pistol.bullet > 0) { //ciklikus �sszecsap�sok
					if (p2.wpn.durability > 0)
					{
						cout << "You attack: " << endl;
						p2.attack(z);
						p2.wpn.usegun();
						cout << "Zombie's life remaining: " << z.life << endl;
						cout << "Weapon durability remaining: " << p2.wpn.durability << endl;
						if (z.life <= 0)
						{
							cout << "Your enemy is dead." << endl;
							break;
						}
						cout << "Zombie attack: " << endl;
						z.attack(p2);
						cout << "Your life remaining: " << p2.life << endl;
						if (p2.life <= 0)
						{
							cout << "You are dead." << endl;
							break;
						}
					}
					if (p2.wpn.durability < 1)
					{
						cout << "You attack with fists: " << endl;
						p2.fistattack(z);
						cout << "Zombie's life remaining: " << z.life << endl;
						if (z.life <= 0)
						{
							cout << "Your enemy is dead." << endl;
							break;
						}
						cout << "Zombie attack: " << endl;
						z.attack(p2);
						cout << "Your life remaining: " << p2.life << endl;
						if (p2.life <= 0)
						{
							cout << "You are dead." << endl;
							break;
						}
					}
				}
			}
			/*else {
				cout << "ERROR" << endl;
			}*/
		}
		/*else {
			cout << "ERROR" << endl;
		}*/
	}
	/*else {
		cout << "ERROR" << endl;
	}*/
}
	